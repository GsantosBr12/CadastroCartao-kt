package com.example.cadastrocartao

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.cadastrocartao.module.CartaoModel
import com.example.cadastrocartao.repository.appDatabase

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val cartaodatabese = appDatabase.getDataBase(this).cartaoDAO()

        val retornoInsert = cartaodatabese.inserCartao(CartaoModel().apply {
            this.numero_cartao = "123456789"
            this.titular = "Gustavo Santos"
            this.cvv = "002"
            this.data_vencimento = "13/04/2027"
        })

        var retornoSelectMultiplo = cartaodatabese.getAll()

        for (item in retornoSelectMultiplo){
            Log.d(
                "Retorno",
                "id_cartao ${item.id_cartao}, numero:${item.numero_cartao}," +
                        "titular :${item.titular},cvv:${item.cvv}, data: ${item.data_vencimento} "
            )
        }

    }
}